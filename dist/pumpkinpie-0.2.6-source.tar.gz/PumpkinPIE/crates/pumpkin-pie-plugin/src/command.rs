//! The `/pie` command, for checking a config by hand.

use pumpkin_plugin_api::command::{
    Arg, ArgumentType, Command, CommandError, CommandNode, CommandSender, ConsumedArgs, StringType,
};
use pumpkin_plugin_api::commands::CommandHandler;
use pumpkin_plugin_api::permission::{Permission, PermissionDefault, PermissionLevel};
use pumpkin_plugin_api::text::{NamedColor, TextComponent};
use pumpkin_plugin_api::{Context, Server};
use tracing::warn;

use pumpkin_pie::builtins;

use crate::plugin;

/// Permission required by `/pie`.
///
/// It has to be namespaced with the provider's exact plugin name, because
/// `Context::register_permission` refuses any other namespace and a node that
/// was never registered denies everyone, operators included.
pub const USE_PERMISSION: &str = "PumpkinPIE:use";

/// The permission node `/pie` is gated on.
#[must_use]
pub const fn use_permission() -> &'static str {
    USE_PERMISSION
}

const USAGE: &str = "Usage: /pie parse <text> to resolve placeholders, \
                     /pie expansions to list the registered expansions.";

/// Registers `/pie` and the permission it needs.
pub fn register(context: Context) {
    if let Err(error) = context.register_permission(&Permission {
        node: USE_PERMISSION.to_string(),
        description: "Allows using /pie.".to_string(),
        default: PermissionDefault::Op(PermissionLevel::Two),
        children: Vec::new(),
    }) {
        // Swallowing this leaves the node unregistered, which denies the command
        // to everyone while looking exactly like the command not existing.
        warn!("could not register {USE_PERMISSION}, /pie will be unusable: {error}");
    }

    context.register_command(root(), USE_PERMISSION);
}

fn root() -> Command {
    Command::new(&["pie".to_string()], "Resolve and inspect placeholders")
        .execute(PieCommand)
        .then(
            CommandNode::literal("parse").execute(PieCommand).then(
                CommandNode::argument("text", &ArgumentType::String(StringType::Greedy))
                    .execute(PieCommand),
            ),
        )
        .then(CommandNode::literal("expansions").execute(PieCommand))
}

struct PieCommand;

impl CommandHandler for PieCommand {
    fn handle(
        &self,
        sender: CommandSender,
        _server: Server,
        args: ConsumedArgs,
    ) -> std::result::Result<i32, CommandError> {
        let requested = match args.get_value("text") {
            Arg::Simple(value) | Arg::Msg(value) => value,
            _ => String::new(),
        };
        if requested.is_empty() {
            return help(&sender);
        }

        let viewer = sender.as_player().map(|player| player.get_name());
        let line = match plugin::try_resolve_line(viewer.as_deref(), &requested) {
            Ok(line) => line,
            Err(error) => {
                sender.send_error(
                    TextComponent::text(&error.to_string()).color_named(NamedColor::Red),
                );
                return Ok(1);
            }
        };
        sender.send_message(TextComponent::text(&line.text));

        if !line.unresolved.is_empty() {
            let note = TextComponent::text(&format!("unresolved: {}", line.unresolved.join(", ")));
            sender.send_error(note.color_named(NamedColor::Red));
        }
        Ok(i32::try_from(line.unresolved.len()).unwrap_or(i32::MAX))
    }
}

fn help(sender: &CommandSender) -> std::result::Result<i32, CommandError> {
    sender.send_message(TextComponent::text(USAGE));
    for builtin in builtins::BUILTINS {
        sender.send_message(TextComponent::text(&format!(
            "%{}%  {}",
            builtin.id, builtin.description
        )));
    }
    for entry in plugin::expansion_summary() {
        sender.send_message(TextComponent::text(&entry));
    }
    Ok(0)
}

/// Both of these mistakes produced the same symptom in game: `/pie` reported
/// "Unknown command", which is what a client shows for a command the player may
/// not use, and the log stayed clean.
#[cfg(test)]
mod tests {
    use super::USE_PERMISSION;
    use pumpkin_pie::PROVIDER;

    #[test]
    fn the_permission_node_is_namespaced_with_the_plugin_name() {
        // `Context::register_permission` rejects a node that does not start with
        // `{plugin name}:`, compared case sensitively.
        assert!(
            USE_PERMISSION.starts_with(&format!("{PROVIDER}:")),
            "{USE_PERMISSION:?} must start with {PROVIDER:?}: or register_permission refuses it"
        );
        assert!(
            USE_PERMISSION.len() > PROVIDER.len() + 1,
            "{USE_PERMISSION:?} needs a key after the colon"
        );
    }

    #[test]
    fn the_metadata_name_matches_the_permission_namespace() {
        // The check above only holds if the plugin's own name is what the node
        // is built from, so pin the pair together.
        assert_eq!(PROVIDER, "PumpkinPIE");
        assert_eq!(USE_PERMISSION, "PumpkinPIE:use");
    }
}
